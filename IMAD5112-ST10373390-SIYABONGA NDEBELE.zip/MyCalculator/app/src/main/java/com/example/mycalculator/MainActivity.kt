package com.example.mycalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {


    private var num1 : TextView? = null
    private var num2 : TextView? = null
    private var textAnswer : TextView? = null
    private var buttonAdd : Button? = null
    private var buttonSub : Button?  = null
    private var buttonMul : Button? = null
    private var buttonDiv : Button? = null
    private var buttonSqr : Button? = null
    private var buttonPow : Button? = null
    private var buttonStat : Button? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        num1 = findViewById(R.id.num1)
        num2 = findViewById(R.id.num2)
        textAnswer = findViewById(R.id.textAnswer)

       val buttonAdd = findViewById<Button>(R.id.buttonAdd)
       val buttonSub = findViewById<Button>(R.id.buttonSub)
       val buttonMul = findViewById<Button>(R.id.buttonMul)
       val buttonDiv = findViewById<Button>(R.id.buttonDiv)
       val buttonSqr = findViewById<Button>(R.id.buttonSqr)
       val buttonPow = findViewById<Button>(R.id.buttonPow)
        val buttonStat = findViewById<Button>(R.id.buttonStat)

        buttonAdd.setOnClickListener {
            add()
        }

        buttonSub.setOnClickListener {
            subtract()
        }

        buttonMul.setOnClickListener{
            multiply()
        }

        buttonDiv.setOnClickListener{
            divide()
        }

        buttonPow.setOnClickListener{
            power()
        }

        buttonSqr.setOnClickListener{
            squareRoot()
        }

        buttonStat.setOnClickListener{
            statistics()

        }







    }
    private fun add(){

        if(isNotEmpty()){
            val input1 = num1?.text.toString().trim().toBigDecimal()
            val input2 = num2?.text.toString().trim().toBigDecimal()
            textAnswer?.text = input1.add(input2).toString()
        }
    }

    private fun isNotEmpty():Boolean {

        var b = true
        if (num1?.text.toString().trim().isEmpty()) {
            num1?.error = "Required"
            b = false
        }

        if (num2?.text.toString().trim().isEmpty()) {
            num2?.error = "Required"
            b = false
        }
        return b
    }


    private fun subtract(){
        if (isNotEmpty()){
            var input1 = num1?.text.toString().trim().toBigDecimal()
            var input2 = num2?.text.toString().trim().toBigDecimal()
            var result = input1.subtract(input2)
            textAnswer?.text = "$input1 - $input2 = $result"
        }

    }

    private fun multiply(){
        if (isNotEmpty()){
            var input1 = num1?.text.toString().trim().toBigDecimal()
            var input2 = num2?.text.toString().trim().toBigDecimal()
            var result = input1.multiply(input2)
            textAnswer?.text =" $input1 x $input2 = $result"
        }


    }

    private fun divide(){
        if (isNotEmpty()){
            var input1 = num1?.text.toString().trim().toBigDecimal()
            var input2 = num2?.text.toString().trim().toBigDecimal()
            var result = input1.divide(input2)
            textAnswer?.text =" $input1 / $input2 = $result"
        }


    }

    private fun squareRoot() {
        if (isNotEmpty()) {
            val inputNumber = num1?.text.toString().trim().toDouble()
            if (inputNumber >= 0) {
                val result = Math.sqrt(inputNumber)
                textAnswer?.text = "√$inputNumber ≈ ${"%.2f".format(result)}"
            } else {
                textAnswer?.text = "Invalid Input"
            }
        }
    }

    private fun power() {
        if (isNotEmpty()) {
            val base = num1?.text.toString().trim().toDouble()
            val exponent = num2?.text.toString().trim().toDouble()
            val result = Math.pow(base, exponent)
            textAnswer?.text = "$base^$exponent ≈ ${"%.2f".format(result)}"}
    }

    private fun statistics(){

    }
}